const express = require("express");
const crypto = require("crypto");
const { readDB, writeDB } = require("../db");

const router = express.Router();

// ============================================================================
// THIS IS THE MOST IMPORTANT FILE IN THE WHOLE BACKEND.
//
// This is the endpoint you give to CPX Research / TheoremReach / any other
// survey or offer partner as your "Postback URL" or "S2S callback URL" in
// their dashboard. When a user finishes a survey on THEIR site, THEIR
// server calls THIS endpoint (server-to-server, not through the user's
// browser) to tell you "this user earned this much money".
//
// Because this endpoint is public on the internet, TWO rules matter a lot:
//
// 1. VERIFY THE SECRET. Anyone who finds this URL could otherwise call it
//    and credit themselves free money. Every real provider lets you
//    configure a secret/hash parameter for exactly this reason — check
//    their docs for the exact parameter name they use, and swap it in
//    below (this file uses a simple ?secret= param as a stand-in).
//
// 2. NEVER PROCESS THE SAME externalId TWICE. Partners sometimes retry a
//    postback if they don't get a fast "OK" response. Without an
//    idempotency check, a retried postback would pay the user twice.
// ============================================================================

// GET /api/postback?user_id=...&external_id=...&amount=...&status=...&secret=...
router.get("/", (req, res) => {
  const { user_id, external_id, amount, status, secret } = req.query;

  if (secret !== process.env.POSTBACK_SECRET) {
    return res.status(403).send("forbidden");
  }
  if (!user_id || !external_id || !amount) {
    return res.status(400).send("missing params");
  }
  if (status && status !== "1" && status.toLowerCase() !== "confirmed") {
    // Some providers send a postback for reversed/cancelled surveys too —
    // acknowledge it but don't pay out.
    return res.status(200).send("ignored: not confirmed");
  }

  const db = readDB();

  const user = db.users.find((u) => u.id === user_id);
  if (!user) {
    return res.status(404).send("unknown user_id");
  }

  if (db.processedPostbacks.includes(external_id)) {
    // Already paid for this exact transaction — don't pay twice.
    return res.status(200).send("already processed");
  }

  const grossAmount = Number(amount);
  if (Number.isNaN(grossAmount) || grossAmount <= 0) {
    return res.status(400).send("invalid amount");
  }

  const userSharePercent = Number(process.env.USER_SHARE_PERCENT || 70);
  const userAmount = Math.round(grossAmount * (userSharePercent / 100));

  db.wallets[user_id] = (db.wallets[user_id] || 0) + userAmount;
  db.transactions.push({
    id: crypto.randomUUID(),
    userId: user_id,
    title: "Task Poora Hua",
    amount: userAmount,
    type: "earning",
    status: "confirmed",
    externalId: external_id,
    createdAt: new Date().toISOString(),
  });
  db.processedPostbacks.push(external_id);

  writeDB(db);

  // Most providers just want a 200 OK — some (like CPX Research) expect the
  // literal text "1" in the response body to mark it as successfully
  // received. Check your provider's docs and adjust this line if needed.
  res.status(200).send("1");
});

module.exports = router;
