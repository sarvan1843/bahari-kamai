const express = require("express");
const router = express.Router();

// This static list stands in for what would normally come live from a
// survey/task partner's API — for example CPX Research's JSON endpoint,
// or TheoremReach's survey list API. When you sign up with one of those
// providers, you swap this hardcoded array for a real fetch() call to
// their API using the App ID/API key they give you.
const TASKS = [
  { id: 1, title: "Shopping Habits Survey", type: "Survey", reward: 35, estimatedMinutes: 8 },
  { id: 2, title: "Naya Fitness App Try Karo", type: "App Install", reward: 60, estimatedMinutes: 5 },
  { id: 3, title: "Product Video Dekho", type: "Video", reward: 15, estimatedMinutes: 2 },
  { id: 4, title: "Dost ko Refer Karo", type: "Referral", reward: 100, estimatedMinutes: 1 },
  { id: 5, title: "Mobile Recharge Habits", type: "Survey", reward: 45, estimatedMinutes: 10 },
  { id: 6, title: "Local Business Review", type: "Task", reward: 50, estimatedMinutes: 6 },
];

// GET /api/tasks
router.get("/", (req, res) => {
  res.json({ tasks: TASKS });
});

module.exports = router;
