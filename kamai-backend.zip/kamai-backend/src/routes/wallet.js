const express = require("express");
const crypto = require("crypto");
const { readDB, writeDB } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

// GET /api/wallet — current balance
router.get("/", (req, res) => {
  const db = readDB();
  res.json({ balance: db.wallets[req.userId] || 0 });
});

// GET /api/wallet/ledger — list of earnings + withdrawals for this user
router.get("/ledger", (req, res) => {
  const db = readDB();
  const entries = db.transactions
    .filter((t) => t.userId === req.userId)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  res.json({ entries });
});

// POST /api/wallet/withdraw
// body: { amount, upiId }
//
// NOTE: this only RECORDS a withdrawal request with status "pending" — it
// does not move real money. Actually sending money needs a payout provider
// like Razorpay Payouts or Cashfree Payouts (both need KYC/business
// verification first). Keeping this as a manual step at the start is a
// deliberate safety choice: you get to eyeball requests before real money
// leaves your account, which matters a lot for catching fraud early on.
router.post("/withdraw", (req, res) => {
  const { amount, upiId } = req.body;
  const minWithdraw = Number(process.env.MIN_WITHDRAW || 100);

  if (!amount || !upiId) {
    return res.status(400).json({ error: "Amount aur UPI ID dono chahiye." });
  }
  if (amount < minWithdraw) {
    return res.status(400).json({ error: `Minimum withdrawal ${minWithdraw} rupaye hai.` });
  }

  const db = readDB();
  const balance = db.wallets[req.userId] || 0;

  if (amount > balance) {
    return res.status(400).json({ error: "Itna balance nahi hai." });
  }

  db.wallets[req.userId] = balance - amount;

  const withdrawalId = crypto.randomUUID();
  db.withdrawals.push({
    id: withdrawalId,
    userId: req.userId,
    amount,
    upiId,
    status: "pending",
    createdAt: new Date().toISOString(),
  });
  db.transactions.push({
    id: crypto.randomUUID(),
    userId: req.userId,
    title: "Withdrawal Request",
    amount: -amount,
    type: "withdrawal",
    status: "pending",
    externalId: withdrawalId,
    createdAt: new Date().toISOString(),
  });

  writeDB(db);
  res.status(201).json({ withdrawalId, status: "pending", newBalance: db.wallets[req.userId] });
});

module.exports = router;
