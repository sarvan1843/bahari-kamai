const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const { readDB, writeDB } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

function signToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: "30d" });
}

// POST /api/auth/signup
// body: { name, phone, password }
router.post("/signup", async (req, res) => {
  const { name, phone, password } = req.body;

  if (!name || !phone || !password) {
    return res.status(400).json({ error: "Naam, phone number, aur password teeno chahiye." });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: "Password kam se kam 6 characters ka hona chahiye." });
  }

  const db = readDB();

  const existing = db.users.find((u) => u.phone === phone);
  if (existing) {
    return res.status(409).json({ error: "Is phone number se pehle se account bana hai. Login karo." });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  const userId = crypto.randomUUID();

  db.users.push({ id: userId, name, phone, passwordHash, createdAt: new Date().toISOString() });
  db.wallets[userId] = 0;
  writeDB(db);

  const token = signToken(userId);
  res.status(201).json({ token, user: { id: userId, name, phone } });
});

// POST /api/auth/login
// body: { phone, password }
router.post("/login", async (req, res) => {
  const { phone, password } = req.body;

  if (!phone || !password) {
    return res.status(400).json({ error: "Phone number aur password chahiye." });
  }

  const db = readDB();
  const user = db.users.find((u) => u.phone === phone);
  if (!user) {
    return res.status(401).json({ error: "Yeh phone number registered nahi hai." });
  }

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) {
    return res.status(401).json({ error: "Password galat hai." });
  }

  const token = signToken(user.id);
  res.json({ token, user: { id: user.id, name: user.name, phone: user.phone } });
});

// GET /api/auth/me — logged-in user ki basic profile + wallet balance
router.get("/me", requireAuth, (req, res) => {
  const db = readDB();
  const user = db.users.find((u) => u.id === req.userId);
  if (!user) return res.status(404).json({ error: "User nahi mila." });

  res.json({
    id: user.id,
    name: user.name,
    phone: user.phone,
    walletBalance: db.wallets[user.id] || 0,
  });
});

module.exports = router;
