// Simple file-based "database" using a JSON file on disk.
//
// Why not a real database from day one? Beginners often get stuck on
// installing/configuring Postgres or MySQL before they've even tested
// their idea. A JSON file is enough to build and test the whole flow.
//
// IMPORTANT: before you have many real users, replace this with a real
// database (PostgreSQL is a good default). The rest of the code (routes)
// won't need to change much — only the functions in this file would.

const fs = require("fs");
const path = require("path");

const DB_PATH = path.join(__dirname, "..", "data", "db.json");

function defaultData() {
  return {
    users: [],          // { id, name, phone, passwordHash, createdAt }
    wallets: {},         // { [userId]: balance }
    transactions: [],    // { id, userId, title, amount, type, status, externalId, createdAt }
    withdrawals: [],     // { id, userId, amount, upiId, status, createdAt }
    processedPostbacks: [], // externalId list, to stop the same postback being paid twice
  };
}

function readDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(defaultData(), null, 2));
  }
  const raw = fs.readFileSync(DB_PATH, "utf-8");
  return JSON.parse(raw);
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = { readDB, writeDB };
